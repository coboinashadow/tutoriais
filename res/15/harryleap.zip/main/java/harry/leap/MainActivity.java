package harry.leap;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.MotionEvent;
import java.util.TimerTask;
import java.util.Timer;

public class MainActivity extends Activity {
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(new HarryLeap(this));
	}
}

class HarryLeap extends View {
	Bitmap harry;
	int alturaPulo,obstaculo1,obstaculo2,obstaculo3;
	float screenWidth,screenHeight,fractionScreenSize;
	void init() {
		obstaculo1=700;
		obstaculo2=710;
		obstaculo3=720;
	}
	TimerTask gameLoop=new TimerTask() { 
		public void run() {
			if(alturaPulo%4==1)alturaPulo+=4;
			if(alturaPulo%4==3)alturaPulo-=4;
			if(alturaPulo>40)alturaPulo=39;
			if(alturaPulo<4)alturaPulo=0;
			obstaculo1-=3;
			obstaculo2-=4;
			obstaculo3-=5;
			if(obstaculo1<-30)obstaculo1=480;
			if(obstaculo2<-30)obstaculo2=530;
			if(obstaculo3<-30)obstaculo3=580;
			if(alturaPulo<10&&obstaculo1<46&&obstaculo1>38)init();
			if(alturaPulo<10&&obstaculo2<46&&obstaculo2>38)init();
			if(alturaPulo<10&&obstaculo3<46&&obstaculo3>38)init();
			invalidate();
		}
	};
	public HarryLeap(Context c) {
		super(c);
	}
	@Override protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		Paint p=new Paint();
		p.setColor(Color.rgb(222,222,222));
		canvas.drawRect(0,0,screenWidth,(float)(screenHeight*.7),p);
		p.setColor(Color.rgb(144,144,144));
		canvas.drawRect(0,(float)(screenHeight*.7),screenWidth,screenHeight,p);
		canvas.drawBitmap(harry,(float)(screenWidth*.1),(float)(screenHeight*.5)-(int)(alturaPulo*fractionScreenSize*3),p);
		p.setColor(Color.rgb(44,44,44));
		canvas.drawCircle(obstaculo1*fractionScreenSize*2,(float)(screenHeight*.62),36,p);
		canvas.drawCircle(obstaculo2*fractionScreenSize*2,(float)(screenHeight*.62),36,p);
		canvas.drawCircle(obstaculo3*fractionScreenSize*2,(float)(screenHeight*.62),36,p);
	}
	@Override protected void onSizeChanged(int width, int height, int oldw, int oldh) {
		super.onSizeChanged(width, height, oldw, oldh);
		screenWidth=width;
		screenHeight=height;
		fractionScreenSize=width/500;
		harry=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.harry), (int)(fractionScreenSize*64), (int)(fractionScreenSize*64), true);
		init();
		new Timer().schedule(gameLoop,0,36);
	}
	@Override public boolean onTouchEvent(MotionEvent event) {
		if(alturaPulo==0)alturaPulo=5;
		return super.onTouchEvent(event);
	}
}
