package bacamarte.game;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity{
	@Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(new Bacamarte(this));
    }
}
class Bacamarte extends View{
	boolean rightButtonPressed,leftButtonPressed,heroDirection,bulletDirection,bulletActive,alive=true;
	int pontos,bulletPosition,altura,bulletAltura,heroPosition=10;
	Bitmap skull,rightButton,heroRight,jumpButton,leftButton,heroLeft,bg,bulletButton;
	Boolean[] enemies=new Boolean[4];
	BulletEnemy[] bullets=new BulletEnemy[10];
	float screenHeight,screenWidth,fractionScreenSize;
	public Bacamarte(Context c){super(c);}
	protected void onSizeChanged(int width,int height,int oldWidth,int oldHeight){
		super.onSizeChanged(width,height,oldWidth,oldHeight);
		screenWidth=width;
		screenHeight=height;
		fractionScreenSize=screenHeight/600;
		for(int x=0;x<4;x++)enemies[x]=new Boolean(false);
		for(int x=0;x<10;x++)bullets[x]=new BulletEnemy();
		bg=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.bg),(int)screenWidth,(int)screenHeight,true);
		skull=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.skull),(int)(100*fractionScreenSize),(int)(100*fractionScreenSize),true);
		leftButton=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.left),(int)(100*fractionScreenSize),(int)(100*fractionScreenSize),true);
		rightButton=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.right),(int)(100*fractionScreenSize),(int)(100*fractionScreenSize),true);
		jumpButton=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.jump),(int)(100*fractionScreenSize),(int)(100*fractionScreenSize),true);
		bulletButton=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.bullet),(int)(80*fractionScreenSize),(int)(80*fractionScreenSize),true);
		heroLeft=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.heroleft),(int)(180*fractionScreenSize),(int)(180*fractionScreenSize),true);
		heroRight=Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.heroright),(int)(180*fractionScreenSize),(int)(180*fractionScreenSize),true);
		new Timer().schedule(gameLoop,0,50);
	}
	public boolean onTouchEvent(MotionEvent me){
		if(me.getAction()==1){
			rightButtonPressed=false;
			leftButtonPressed=false;
		}else if(!alive&&me.getX()>0.8*screenWidth&&me.getY()<0.6*screenHeight){
			pontos=0;
			alive=true;
			bulletActive=false;
			heroPosition=10;
			heroDirection=false;
			altura=0;
			for(int x=0;x<4;x++)enemies[x]=new Boolean(false);
			for(int x=0;x<10;x++)bullets[x]=new BulletEnemy();
		}else{
			if(me.getX()<0.02*screenWidth+(120*fractionScreenSize)&&me.getY()>0.74*screenHeight){
				heroDirection=true;
				leftButtonPressed=true;
			}
			if(me.getX()>0.02*screenWidth+(120*fractionScreenSize)&&me.getX()<0.2*screenWidth+(120*fractionScreenSize)&&me.getY()>0.74*screenHeight){
				heroDirection=false;
				rightButtonPressed=true;
			}
			if(me.getX()>screenWidth-0.02*screenWidth-(120*fractionScreenSize)&&me.getY()>0.74*screenHeight&&altura==0)
				altura=5;
			if(me.getX()<screenWidth-0.02*screenWidth-(120*fractionScreenSize)&&me.getX()>screenWidth-0.2*screenWidth-(120*fractionScreenSize)&&me.getY()>0.74*screenHeight&&!bulletActive){
				bulletPosition=heroPosition;
				bulletDirection=heroDirection;
				bulletAltura=altura;
				bulletActive=true;
			}
		}
		return true;
	}
	protected void onDraw(Canvas canvas){
		super.onDraw(canvas);
		Paint paint=new Paint();
		canvas.drawBitmap(bg,0,0,paint);
		paint.setColor(Color.rgb(160,160,160));
		canvas.drawRect(0,(float)(0.74*screenHeight),screenWidth,screenHeight,paint);
		canvas.drawRect(0,(float)(0.52*screenHeight),fractionScreenSize*100,(float)(0.53*screenHeight),paint);
		canvas.drawRect(screenWidth-fractionScreenSize*100,(float)(0.52*screenHeight),screenWidth,(float)(0.53*screenHeight),paint);
		if(!alive){
			paint.setColor(Color.rgb(65,65,65));
			canvas.drawRect(0,0,screenWidth,screenHeight,paint);
			paint.setColor(Color.rgb(2,2,2));
			paint.setTextAlign(Align.RIGHT);
			paint.setTextSize((float)(0.16*screenHeight));
			canvas.drawText(pontos+" x",(float)(0.85*screenWidth),(float)(0.22*screenHeight),paint);
			canvas.drawBitmap(skull,(float)(0.87*screenWidth),(float)(0.08*screenHeight),paint);
		}else{
			canvas.drawBitmap(leftButton,(float)(0.02*screenWidth),(float)(0.79*screenHeight),paint);
			canvas.drawBitmap(rightButton,(float)(0.02*screenWidth)+(120*fractionScreenSize),(float)(0.79*screenHeight),paint);
			canvas.drawBitmap(jumpButton,(float)(0.994*screenWidth-(120*fractionScreenSize)),(float)(0.79*screenHeight),paint);
			canvas.drawBitmap(bulletButton,(float)(0.902*screenWidth-(120*fractionScreenSize)),(float)(0.81*screenHeight),paint);
			if(enemies[0])canvas.drawBitmap(heroRight,screenWidth/24*-1,(float)(0.228*screenHeight),paint);
			if(enemies[1])canvas.drawBitmap(heroLeft,screenWidth/24*22,(float)(0.228*screenHeight),paint);
			if(enemies[2])canvas.drawBitmap(heroRight,screenWidth/24*-1,(float)(0.44*screenHeight),paint);
			if(enemies[3])canvas.drawBitmap(heroLeft,screenWidth/24*22,(float)(0.44*screenHeight),paint);
			paint.setColor(Color.rgb(2,2,2));
			for(int x=0;x<10;x++)if(bullets[x].active)
				if(bullets[x].position>0||bullets[x].position<22)
					canvas.drawCircle((-1+bullets[x].position)*screenWidth/24+screenWidth/12,(float)(0.64*screenHeight-(5*fractionScreenSize*bullets[x].altura)),screenWidth/80,paint);
			if(heroDirection)canvas.drawBitmap(heroLeft,screenWidth/24*(-1+heroPosition),(float)(0.44*screenHeight-(5*fractionScreenSize*altura)),paint);
			else canvas.drawBitmap(heroRight,screenWidth/24*(-1+heroPosition),(float)(0.44*screenHeight-(5*fractionScreenSize*altura)),paint);
			if(bulletActive)canvas.drawCircle(screenWidth/24*(-1+bulletPosition)+screenWidth/12,(float)(0.64*screenHeight-(5*fractionScreenSize*bulletAltura)),screenWidth/80,paint);
		}
	}
	TimerTask gameLoop=new TimerTask() { 
		public void run() {
			if(alive){
				if(rightButtonPressed&&heroPosition<22)heroPosition++;
				if(leftButtonPressed&&heroPosition>1)heroPosition--;
				if(altura%4==1)altura+=4;
				if(altura%4==3)altura+=-4;
				if(altura>28)altura=31;
				if(altura<2)altura=0;
				if(bulletActive){
					if(bulletDirection)bulletPosition--;
					else bulletPosition++;
					if(bulletPosition>22||bulletPosition<-1)bulletActive=false;
					if(enemies[0]&&bulletAltura>12&&bulletPosition<-1){
						pontos++;
						enemies[0]=false;
					}
					if(enemies[1]&&bulletAltura>12&&bulletPosition>22){
						pontos++;
						enemies[1]=false;
					}
					if(enemies[2]&&bulletAltura<12&&bulletPosition<-1){
						pontos++;
						enemies[2]=false;
					}
					if(enemies[3]&&bulletAltura<12&&bulletPosition>22){
						pontos++;
						enemies[3]=false;
					}
				}
			}
			float dificulty=0.003F;
			if(pontos>15)dificulty=0.007F;
			if(pontos>25)dificulty=0.013F;
			for(int x=0;x<10;x++)
			if(!bullets[x].active&&new Random().nextFloat()<dificulty){
				if(new Random().nextBoolean()){
					bullets[x].position=0;
					bullets[x].direction=false;
				}else{
					bullets[x].position=22;
					bullets[x].direction=true;
				}
				if(new Random().nextBoolean())bullets[x].altura=0;
				else bullets[x].altura=25;
				bullets[x].active=true;
				if(bullets[x].altura==25&&!bullets[x].direction)enemies[0]=true;
				if(bullets[x].altura==25&&bullets[x].direction)enemies[1]=true;
				if(bullets[x].altura==0&&!bullets[x].direction)enemies[2]=true;
				if(bullets[x].altura==0&&bullets[x].direction)enemies[3]=true;
				for(int y=0;y<10;y++)if(x!=y&&bullets[y].active&&(bullets[y].position<4||bullets[y].position>18))bullets[x].active=false;
			}
			for(int x=0;x<10;x++)
				if(bullets[x].active){
					bullets[x].delay++;
					if(bullets[x].delay==3)bullets[x].delay=0;
					if(bullets[x].delay==2){
						if(bullets[x].direction)bullets[x].position--;
						else bullets[x].position++;
					}
					if(bullets[x].position<-1||bullets[x].position>22)bullets[x].active=false;
					if(bullets[x].position==heroPosition){
						if(altura>=12==bullets[x].altura>=12)
							alive=false;
					}
				}
			invalidate();
		}
	};
}
class BulletEnemy{
	boolean active,direction;
	int altura,delay,position;
}
